-- FS25_QuietLoadingScreen
-- Mutes environment and vehicle sounds during the loading screens until the map is visible

local QuietLoadingScreen = {}
QuietLoadingScreen.hasRestored = false

local function muteAudio()
    if QuietLoadingScreen.hasRestored then return end
    if setAudioGroupVolume ~= nil and AudioGroup ~= nil then
        if AudioGroup.ENVIRONMENT ~= nil then
            setAudioGroupVolume(AudioGroup.ENVIRONMENT, 0)
        end
        if AudioGroup.VEHICLE ~= nil then
            setAudioGroupVolume(AudioGroup.VEHICLE, 0)
        end
    end
end

-- Immediately mute as soon as the mod script is loaded by the engine:
muteAudio()

function QuietLoadingScreen:restoreAudio()
    if self.hasRestored then return end
    self.hasRestored = true

    local envVol = 0.7
    local vehVol = 1.0

    if g_gameSettings ~= nil and g_gameSettings.getValue ~= nil and GameSettings ~= nil and GameSettings.SETTING ~= nil then
        if GameSettings.SETTING.VOLUME_ENVIRONMENT ~= nil then
            local val = g_gameSettings:getValue(GameSettings.SETTING.VOLUME_ENVIRONMENT)
            if val ~= nil then envVol = val end
        end
        if GameSettings.SETTING.VOLUME_VEHICLE ~= nil then
            local val = g_gameSettings:getValue(GameSettings.SETTING.VOLUME_VEHICLE)
            if val ~= nil then vehVol = val end
        end
    end

    if setAudioGroupVolume ~= nil and AudioGroup ~= nil then
        if AudioGroup.ENVIRONMENT ~= nil then
            setAudioGroupVolume(AudioGroup.ENVIRONMENT, envVol)
        end
        if AudioGroup.VEHICLE ~= nil then
            setAudioGroupVolume(AudioGroup.VEHICLE, vehVol)
        end
    end
    print("[QuietLoadingScreen] Map is now visible. Audio volume restored to normal.")
end

-- Hook into MessageCenter for when mission starts
if g_messageCenter ~= nil and MessageType ~= nil then
    if MessageType.CURRENT_MISSION_START ~= nil then
        g_messageCenter:subscribeOneshot(MessageType.CURRENT_MISSION_START, QuietLoadingScreen.restoreAudio, QuietLoadingScreen)
    elseif MessageType.CURRENT_MISSION_LOADED ~= nil then
        g_messageCenter:subscribeOneshot(MessageType.CURRENT_MISSION_LOADED, QuietLoadingScreen.restoreAudio, QuietLoadingScreen)
    end
end

-- Hook into FSCareerMission and FSBaseMission onStartMission
if FSCareerMission ~= nil and FSCareerMission.onStartMission ~= nil then
    local oldCareerStart = FSCareerMission.onStartMission
    FSCareerMission.onStartMission = function(...)
        oldCareerStart(...)
        QuietLoadingScreen:restoreAudio()
    end
end
if FSBaseMission ~= nil and FSBaseMission.onStartMission ~= nil then
    local oldBaseStart = FSBaseMission.onStartMission
    FSBaseMission.onStartMission = function(...)
        oldBaseStart(...)
        QuietLoadingScreen:restoreAudio()
    end
end

-- Ensure mute remains in effect during each frame of the loading screen if engine tries to reset volume
addModEventListener(QuietLoadingScreen)

function QuietLoadingScreen:update(dt)
    if not self.hasRestored then
        muteAudio()
    else
        removeModEventListener(self)
    end
end
