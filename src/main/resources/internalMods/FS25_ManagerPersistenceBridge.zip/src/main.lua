-- FS25_ManagerPersistenceBridge
-- Player position, vehicle driver seat persistence, and facing yaw alignment

Player.createData = Utils.overwrittenFunction(Player.createData, function(self, superFunc, ...)
    local playerData = superFunc(self, ...)
    playerData.spawnVehicleUniqueId = nil

    local x, y, z = self:getPosition()
    local yaw = 0

    if self.camera ~= nil and self.camera.getRotation ~= nil then
        local _, camYaw = self.camera:getRotation()
        yaw = camYaw or 0
    elseif self.getMapPositionAndLookYaw ~= nil then
        local _, _, camYaw = self:getMapPositionAndLookYaw()
        yaw = camYaw or 0
    elseif self.mover ~= nil and self.mover.getMovementYaw ~= nil then
        yaw = self.mover:getMovementYaw() or 0
    end

    if self:getIsInVehicle() then
        local currentVehicle = self:getCurrentVehicle()
        if currentVehicle ~= nil then
            playerData.spawnVehicleUniqueId = currentVehicle.uniqueId
            local exitPoint = currentVehicle:getExitNode(self)
            if exitPoint ~= nil then
                x, y, z = getWorldTranslation(exitPoint)
                local dx, _, dz = localDirectionToWorld(exitPoint, 0, 0, 1)
                yaw = MathUtil.getYRotationFromDirection(dx, dz)
            end
        end
    end

    playerData.spawnPositionX = x
    playerData.spawnPositionY = y
    playerData.spawnPositionZ = z
    playerData.spawnYaw = yaw

    return playerData
end)

local function enterTargetVehicle(player, vehicle)
    if player == nil or vehicle == nil then return end
    if vehicle.getIsEnterable ~= nil and not vehicle:getIsEnterable() then return end
    if vehicle.getIsControlled ~= nil and vehicle:getIsControlled() then return end

    if player.requestToEnterVehicle ~= nil then
        player:requestToEnterVehicle(vehicle)
    elseif g_localPlayer ~= nil and g_localPlayer.requestToEnterVehicle ~= nil then
        g_localPlayer:requestToEnterVehicle(vehicle)
    end
end

Player.show = Utils.appendedFunction(Player.show, function(self)
    if self.isOwner then
        if self.spawnVehicle ~= nil then
            local targetVehicle = self.spawnVehicle
            self.spawnVehicle = nil
            enterTargetVehicle(self, targetVehicle)
        else
            -- Spawning on foot: apply spawnYaw to camera so player faces the designated direction
            if self.spawnYaw ~= nil and self.camera ~= nil and self.camera.setRotation ~= nil then
                local currentPitch = 0
                if self.camera.getRotation ~= nil then
                    currentPitch = self.camera:getRotation()
                end
                self.camera:setRotation(currentPitch or 0, self.spawnYaw, 0)
            end
        end
    end
end)

Player.writeStream = Utils.prependedFunction(Player.writeStream, function(self, streamId, connection)
    if streamWriteBool(streamId, self.spawnVehicleTmp ~= nil) then
        NetworkUtil.writeNodeObject(streamId, self.spawnVehicleTmp)
        self.spawnVehicleTmp = nil
    end
end)

Player.readStream = Utils.prependedFunction(Player.readStream, function(self, streamId, connection, objectId)
    if streamReadBool(streamId) then
        self.spawnVehicle = NetworkUtil.readNodeObject(streamId)
    end
end)
